# 灵山大掌门 · 修仙门派经营原型 v0.7.2

> 后续模型或开发者接手前，请先阅读 [PROJECT_HANDOFF.md](./PROJECT_HANDOFF.md)。
> 每个版本开工前必须先整理版更明细给用户确认，明细见 [VERSION_PLANS.md](./VERSION_PLANS.md)，用户确认后才允许写代码。

对标《百货商场物语》核心机制的修仙门派经营 H5 原型。验证"建造-生产-加工-售卖-访客"核心循环与"布局相性 Combo"玩法。
